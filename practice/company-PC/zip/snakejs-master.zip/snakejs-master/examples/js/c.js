snake.define(function(require, exports, module) {
  exports.d = function() {
    console.log('c.d');
  };
});
